/*
 * =====================================================================================
 *
 *       Filename:  arch.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/20/2012 10:57:09 AM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Chen Yuheng (Chen Yuheng), chyh1990@163.com
 *   Organization:  Tsinghua Unv.
 *
 * =====================================================================================
 */
#ifndef __ARM_MACH_ARCH_H
#define __ARM_MACH_ARCH_H

#include <arm.h>

#endif
