#ifndef  MACH_BOARD_H
#define  MACH_BOARD_H

#include "board-raspberrypi.h"

#endif
