#ifndef __GLUE_UCORE_MEMLAYOUT_H__
#define __GLUE_UCORE_MEMLAYOUT_H__

#include <glue_memlayout.h>

#endif
