#ifndef __GLUE_UCORE_ENTRY_H__
#define __GLUE_UCORE_ENTRY_H__

extern volatile int init_finished;

#endif
