#ifndef __KERN_SCHEDULE_SCHED_MLFQ_H__
#define __KERN_SCHEDULE_SCHED_MLFQ_H__

#include <sched.h>

extern struct sched_class MLFQ_sched_class;

#endif /* !__KERN_SCHEDULE_SCHED_MLFQ_H__ */
