#ifndef __DOSM_INIT_H__
#define __DOSM_INIT_H__

extern ushort ipi_vector;

#endif
