#ifndef __MP_H__
#define __MP_H__

int mp_init(void);

#endif
