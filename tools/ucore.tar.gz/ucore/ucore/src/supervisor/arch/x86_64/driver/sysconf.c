#include <sysconf.h>

sysconf_s sysconf;
