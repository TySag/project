#ifndef __ARCH_GLUE_ARM_INCLUDE_MEMLAYOUT_H__
#define __ARCH_GLUE_ARM_INCLUDE_MEMLAYOUT_H__

//board specific layout
#include <memlayout.h>

#endif /* !__ARCH_TEMPLATE_INCLUDE_MEMLAYOUT_H__ */
