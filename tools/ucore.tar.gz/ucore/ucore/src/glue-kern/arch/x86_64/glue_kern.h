#ifndef __GLUE_KERN_H__
#define __GLUE_KERN_H__

#endif /* !__GLUE_KERN_H__ */
